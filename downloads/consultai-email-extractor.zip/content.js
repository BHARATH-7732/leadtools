(() => {
  if (window.__consultAIEmailExtractorLoaded) {
    return;
  }
  window.__consultAIEmailExtractorLoaded = true;

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function pageInfo() {
    const m = document.body.innerText.match(/Page\s+(\d+)\s+of\s+(\d+)/i);
    return m ? { page: +m[1], total: +m[2] } : null;
  }

  async function waitForPage(target) {
    for (let i = 0; i < 50; i++) {
      const p = pageInfo();
      if (p && p.page === target) {
        await sleep(1200);
        return true;
      }
      await sleep(500);
    }
    return false;
  }

  function collectEmails(emails) {
    document.querySelectorAll("tbody tr").forEach(row => {
      const found = row.innerText.match(
        /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi
      );
      if (found) found.forEach(e => emails.add(e.trim().toLowerCase()));
    });
  }

  function findButton(label) {
    return [...document.querySelectorAll("button")].find(b =>
      b.innerText.trim().toLowerCase() === label &&
      !b.disabled &&
      b.offsetParent !== null
    );
  }

  function makeBox() {
    document.getElementById("consultAIEmailBox")?.remove();

    const box = document.createElement("div");
    box.id = "consultAIEmailBox";
    box.innerHTML = `
      <div id="ceh">
        <span>📧 Mail Extractor</span><span id="cex">×</span>
      </div>
      <div id="ces">Ready</div>
      <div id="cec">0 emails</div>
      <div id="cep"><div id="ceb"></div></div>
      <button id="cecopy" disabled>Copy All Emails</button>
      <textarea id="cer" readonly placeholder="Emails will appear here..."></textarea>
    `;

    box.style.cssText = `
      position:fixed;top:18px;right:18px;width:285px;height:335px;
      background:#fff;color:#202124;border:1px solid #dadce0;
      border-radius:10px;box-shadow:0 5px 25px rgba(0,0,0,.25);
      z-index:2147483647;font:13px Arial,sans-serif;overflow:hidden;
    `;

    document.body.appendChild(box);

    const header = box.querySelector("#ceh");
    header.style.cssText =
      "height:38px;background:#202124;color:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 12px;font-weight:bold;cursor:move";
    box.querySelector("#cex").style.cssText =
      "cursor:pointer;font-size:20px";
    box.querySelector("#ces").style.cssText =
      "padding:10px 12px 3px;font-weight:bold";
    box.querySelector("#cec").style.cssText =
      "padding:3px 12px;color:#5f6368";
    box.querySelector("#cep").style.cssText =
      "margin:6px 12px;height:6px;background:#eee;border-radius:5px;overflow:hidden";
    box.querySelector("#ceb").style.cssText =
      "width:0;height:100%;background:#1a73e8;transition:width .2s";
    box.querySelector("#cecopy").style.cssText =
      "margin:6px 12px;width:calc(100% - 24px);height:32px;border:0;border-radius:6px;background:#1a73e8;color:#fff;font-weight:bold;cursor:pointer";
    box.querySelector("#cer").style.cssText =
      "margin:6px 12px;width:calc(100% - 24px);height:175px;box-sizing:border-box;resize:none;border:1px solid #ddd;border-radius:6px;padding:7px;font-size:12px";

    box.querySelector("#cex").onclick = () => box.remove();

    box.querySelector("#cecopy").onclick = async () => {
      await navigator.clipboard.writeText(box.querySelector("#cer").value);
      const b = box.querySelector("#cecopy");
      b.textContent = "✓ Copied!";
      setTimeout(() => b.textContent = "Copy All Emails", 1200);
    };

    let dragging = false, ox = 0, oy = 0;
    header.onmousedown = e => {
      dragging = true;
      ox = e.clientX - box.offsetLeft;
      oy = e.clientY - box.offsetTop;
    };
    document.addEventListener("mousemove", e => {
      if (!dragging) return;
      box.style.left = `${e.clientX - ox}px`;
      box.style.top = `${e.clientY - oy}px`;
      box.style.right = "auto";
    });
    document.addEventListener("mouseup", () => dragging = false);

    return box;
  }

  async function run() {
    const box = makeBox();
    const status = box.querySelector("#ces");
    const count = box.querySelector("#cec");
    const bar = box.querySelector("#ceb");
    const results = box.querySelector("#cer");
    const copy = box.querySelector("#cecopy");
    const emails = new Set();

    let p = pageInfo();

    // Return to page 1 if currently later in the list.
    if (p && p.page > 1) {
      while ((p = pageInfo()) && p.page > 1) {
        const prev = findButton("previous");
        if (!prev) break;
        const target = p.page - 1;
        prev.click();
        if (!(await waitForPage(target))) break;
      }
    }

    while (true) {
      const info = pageInfo();
      const current = info?.page || 1;
      const total = info?.total || 1;

      status.textContent = `Collecting page ${current} of ${total}...`;
      bar.style.width = `${Math.min(100, current / total * 100)}%`;

      await sleep(900);
      collectEmails(emails);

      count.textContent = `${emails.size} unique emails`;
      results.value = [...emails].join("\n");

      if (current >= total) break;

      const next = findButton("next");
      if (!next) {
        status.textContent = "Next button not found.";
        break;
      }

      next.click();

      if (!(await waitForPage(current + 1))) {
        status.textContent = "Page change timed out.";
        break;
      }
    }

    bar.style.width = "100%";
    status.textContent = `✓ Finished — ${emails.size} unique emails`;
    count.textContent = `${emails.size} unique emails`;
    results.value = [...emails].join("\n");
    copy.disabled = emails.size === 0;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.action === "start") {
      run();
      sendResponse({ok: true});
    }
    return true;
  });
})();