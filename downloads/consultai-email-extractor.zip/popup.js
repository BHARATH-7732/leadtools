const button = document.getElementById("start");
const status = document.getElementById("status");

button.addEventListener("click", async () => {
  button.disabled = true;
  status.textContent = "Starting...";

  try {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});

    await chrome.scripting.executeScript({
      target: {tabId: tab.id},
      files: ["content.js"]
    });

    const result = await chrome.tabs.sendMessage(tab.id, {action: "start"});
    status.textContent = result?.ok ? "Extractor started." : "Could not start.";
  } catch (e) {
    status.textContent = "Open the leads page and try again.";
    button.disabled = false;
  }
});